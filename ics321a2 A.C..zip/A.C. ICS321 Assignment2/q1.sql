SELECT func, pce
FROM pcefunc
WHERE year = 2010
AND quarter = 1;